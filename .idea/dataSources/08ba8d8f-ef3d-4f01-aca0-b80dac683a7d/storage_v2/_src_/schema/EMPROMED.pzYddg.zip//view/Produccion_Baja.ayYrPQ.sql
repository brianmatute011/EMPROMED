create definer = root@localhost view Produccion_Baja as
select `T`.`nombre` AS `nombre`
from `EMPROMED`.`Evaluacion` `E`
         join `EMPROMED`.`Trabajador` `T`
where ((`E`.`resultado` = 'D') and (`T`.`CI` = `E`.`CIRESP`))
group by `T`.`nombre`;

